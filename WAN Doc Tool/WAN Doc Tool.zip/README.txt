WAN Show Doc Creation Tool
Requirements: Install Python 2.7

1. Create a file called source.txt in the pwd.
2. Fill the sourcefile.txt file with links to the forum news section.
3. Run the Python Program.
4. Copy and paste from the produced .html file

Known Bugs:
- When displaying the titles in the command windows it does not convert from UTF-8 to ASCII.
- Does not disregard text after links.
- Does not link rejected items.